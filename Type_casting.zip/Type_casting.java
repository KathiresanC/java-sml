package SML;

import java.util.Scanner;

public class Type_casting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/*//implicit type casting
		int i=100;
		
		double d=50;
		
		char c='a';
		
		float l=i;   // auto conversion
		
		double d1=l; // auto conversion
		
		double mydouble =(d/l)+(i/c)+(l/d1);// here calculation takes place after conversion char c is promoted to integer 
		
		System.out.println(mydouble);*/
		
		//explicit type casting
		Scanner sc=new Scanner(System.in); 
		
		int i=sc.nextInt(); // getting input as integer from user
		
		float f=(float)i; // converting integer to float
		
		byte b=(byte)i; // converting integer to byte
		
		int Myint=(int)f; // converting float to integer
		
		double d=(double)i; //changing data type from integer to double
		
		System.out.println("double = "+d+" byte = "+ b+" float = "+f);
		System.out.print("integer = "+Myint);
		
	}
}
